package com.udacity.asteroidradar.main

import android.os.Build
import android.os.Bundle
import android.view.*
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.udacity.asteroidradar.Asteroid
import com.udacity.asteroidradar.NetworkStatus
import com.udacity.asteroidradar.R
import com.udacity.asteroidradar.bindProgressBarToStatus
import com.udacity.asteroidradar.databinding.FragmentMainBinding

@RequiresApi(Build.VERSION_CODES.N)
class MainFragment : Fragment() {

    private val viewModel: MainViewModel by lazy {
        val activity = requireNotNull(this.activity) {}

        ViewModelProvider(
                this,
                MainViewModel.Factory(activity.application)
        ).get(MainViewModel::class.java)
    }



    override  fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                               savedInstanceState: Bundle?): View? {
        val binding = FragmentMainBinding.inflate(inflater)
//      setting lifecycle owner
        binding.lifecycleOwner = this
//      setting viewModel
        binding.viewModel = viewModel

        //        adapter for the recyclerview to display our asteroid datad
        val mainAdapter = MainAsteroidListAdapter(::asteroidClick)
//        setting the adapter for the recycler view in which the asteroids will be displayed
        binding.asteroidRecycler.adapter = mainAdapter
        viewModel.asteroidList.observe(viewLifecycleOwner, Observer {
            it?.let {
                mainAdapter.submitList(it)
            }
        })
//        status of the asteroid list data
        viewModel.status.observe(viewLifecycleOwner, Observer {
            it.let {
                when(it){
                    NetworkStatus.LOADING -> binding.statusLoadingWheel.visibility = View.VISIBLE
                    NetworkStatus.DONE -> binding.statusLoadingWheel.visibility = View.INVISIBLE
                    NetworkStatus.ERROR -> binding.errorGettingDataTextView.visibility = View.VISIBLE
                }
            }
        })

//      status of the picture of the day
        viewModel.pictureOfDayStatus.observe(viewLifecycleOwner, Observer {
            it.let {
                when(it){
                    NetworkStatus.LOADING -> binding.statusLoadingWheel.visibility = View.VISIBLE
                    NetworkStatus.DONE -> binding.statusLoadingWheel.visibility = View.INVISIBLE
                    NetworkStatus.ERROR -> binding.imageOfTheDay.setImageResource(R.drawable.ic_no_photo)
                }
            }
        })

        binding.executePendingBindings()
//      allowing the user to have the menu only in the MainFragment and let them choose out
//      of the three choices in the main_overflow_menu
        setHasOptionsMenu(true)

        return binding.root
    }

    fun asteroidClick(asteroid: Asteroid) {
        this.findNavController().navigate(MainFragmentDirections.actionMainFragmentToDetailFragment(asteroid))
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.main_overflow_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

//  when the users chooses one of the options in the main_overflow_menu
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//  uses the viewModel to get & refresh the new data based on the chosen option
        when(item.itemId){
            R.id.show_week -> {
//                asking for/getting the data of the current week
                viewModel.setFilterAsWeek()
                return true
            }
            R.id.show_today -> {
//                asking for/getting the data of the current day
                viewModel.setFilterAsToday()
                return true
            }
            R.id.show_saved -> {
//                asking for/getting saved data
                viewModel.setFilterAsSaved()
                return true
            }
        }
        return true
    }
}
