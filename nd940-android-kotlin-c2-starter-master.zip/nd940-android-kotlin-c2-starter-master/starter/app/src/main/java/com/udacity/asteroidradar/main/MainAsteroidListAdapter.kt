package com.udacity.asteroidradar.main

import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.udacity.asteroidradar.*
import com.udacity.asteroidradar.databinding.AsteroidMainItemBinding
import com.udacity.asteroidradar.databinding.PictureOfTheDayBinding
import kotlin.coroutines.coroutineContext

class MainAsteroidListAdapter(private val asteroidClick: (asteroid: Asteroid) -> Unit) :
    androidx.recyclerview.widget.ListAdapter<Asteroid, MainAsteroidListAdapter.ItemViewHolder>(DiffCallback) {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val mainItemBinding: AsteroidMainItemBinding = AsteroidMainItemBinding.inflate(LayoutInflater.from(parent.context))
        return ItemViewHolder(mainItemBinding)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val asteroid = getItem(position)
        holder.also {
            it.itemView.setOnClickListener{
                asteroidClick(asteroid)
            }
            it.bind(asteroid)
        }

    }


    class ItemViewHolder(private var binding: AsteroidMainItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(asteroid: Asteroid) {
            binding.codeName.text = asteroid.codename
            binding.closeApproachDate.text = asteroid.closeApproachDate
            binding.statusImageView.bindAsteroidStatusImage(asteroid.isPotentiallyHazardous)
        }

        companion object {
            fun from(parent: ViewGroup): RecyclerView.ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = AsteroidMainItemBinding.inflate(layoutInflater, parent, false)

                return ItemViewHolder(binding)
            }
        }



    }

    companion object DiffCallback : DiffUtil.ItemCallback<Asteroid>() {
        override fun areItemsTheSame(oldItem: Asteroid, newItem: Asteroid): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: Asteroid, newItem: Asteroid): Boolean {
            return oldItem.id == newItem.id
        }
    }

}
