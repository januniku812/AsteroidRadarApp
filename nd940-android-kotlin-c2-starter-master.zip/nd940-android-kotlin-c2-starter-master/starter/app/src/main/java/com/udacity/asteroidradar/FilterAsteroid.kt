package com.udacity.asteroidradar

enum class FilterAsteroid {
    ALL,
    WEEK,
    SAVED,
    TODAY
}