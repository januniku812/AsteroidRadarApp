package com.udacity.asteroidradar.main

import android.app.Application
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.*
import com.udacity.asteroidradar.Asteroid
import com.udacity.asteroidradar.Constants.API_KEY
import com.udacity.asteroidradar.FilterAsteroid
import com.udacity.asteroidradar.NetworkStatus
import com.udacity.asteroidradar.PictureOfDay
import com.udacity.asteroidradar.api.AsteroidApiService
import com.udacity.asteroidradar.database.getDatabase
import com.udacity.asteroidradar.repository.AsteroidRepository
import com.udacity.asteroidradar.utils.DateFormaterUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import kotlin.collections.ArrayList

@RequiresApi(Build.VERSION_CODES.N)
public class MainViewModel(application: Application) : AndroidViewModel(application) {

//    database
    private val database = getDatabase(application)
//    repository
    private val asteroidRepository = AsteroidRepository(database)

//  status of the data(e.g. if its loading than the progress bar should spin)
    private val _status = MutableLiveData<NetworkStatus>()
    val status: LiveData<NetworkStatus>
        get() = _status
//    picture of the day
    private val _pictureOfDay = MutableLiveData<PictureOfDay>()
    val pictureOfDay: LiveData<PictureOfDay>
        get() = _pictureOfDay
//        picture of the day status
    private val _pictureOfDayStatus = MutableLiveData<NetworkStatus>()
    val pictureOfDayStatus: LiveData<NetworkStatus>
        get() = _pictureOfDayStatus

//  filter
    private var _filterAsteroid = MutableLiveData(FilterAsteroid.ALL)

//  asteroid list to be displayed in the recycler view
//private val _asteroidList = MutableLiveData<List<Asteroid>>()
//    val asteroidList: LiveData<List<Asteroid>>
//        get() = _asteroidList

val asteroidList = Transformations.switchMap(_filterAsteroid) {
    when (it!!) {
        FilterAsteroid.WEEK -> asteroidRepository.weekAsteroids
        FilterAsteroid.TODAY -> asteroidRepository.todayAsteroids
        else -> asteroidRepository.allAsteroids
    }
}
    //    setter methods for the filter
    fun setFilterAsAll(){
        _filterAsteroid.value = FilterAsteroid.ALL

    }

    fun setFilterAsWeek(){
        _filterAsteroid.value = FilterAsteroid.WEEK
    }

    fun setFilterAsToday(){
        _filterAsteroid.value = FilterAsteroid.TODAY
    }

    fun setFilterAsSaved(){
        _filterAsteroid.value = FilterAsteroid.SAVED
    }


    init {
//        when this class is first initialized then the filter should be all asteroids
//        this will be the case until the user selects a different option from
        setFilterAsAll()
        viewModelScope.launch {
            asteroidRepository.refreshAsteroids()
            refreshPictureOfDay()
            checkIfLoaded()
        }

    }

    suspend fun checkIfLoaded(){
        if(asteroidRepository.status == NetworkStatus.DONE){
            _status.value = NetworkStatus.DONE
        }
        else if(asteroidRepository.status == NetworkStatus.ERROR){
            _status.value = NetworkStatus.ERROR
        }
        else{
            _status.value = NetworkStatus.LOADING
        }
    }


    private suspend fun refreshPictureOfDay() {
        _pictureOfDayStatus.value = NetworkStatus.LOADING
        withContext(Dispatchers.IO) {
            try {
                _pictureOfDay.postValue(
                    AsteroidApiService.AsteroidApi.retrofitService.getPictureOfTheDay(API_KEY))
                _pictureOfDayStatus.value = NetworkStatus.DONE
            }
            catch (err: Exception) {
                Log.e("refreshPictureOfDay", err.printStackTrace().toString())
            }
        }
    }

    class Factory(val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return MainViewModel(application) as T
            }
            throw IllegalArgumentException("Unable to construct ViewModel")
        }
    }


}