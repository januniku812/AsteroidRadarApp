package com.udacity.asteroidradar

import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.squareup.picasso.Picasso
import com.udacity.asteroidradar.databinding.PictureOfTheDayBinding
import com.udacity.asteroidradar.main.MainViewModel


@BindingAdapter("statusIcon")
fun ImageView.bindAsteroidStatusImage(isHazardous: Boolean) {
    if(isHazardous) {
        setImageResource(R.drawable.ic_status_potentially_hazardous)
        contentDescription = context.getString(R.string.potentially_hazardous_asteroid_image)
    } else {
        setImageResource(R.drawable.ic_status_normal)
        contentDescription = context.getString(R.string.not_hazardous_asteroid_image)
    }
}

// Picture of the day binding

@BindingAdapter("pictureOfTheDayUrl")
fun ImageView.bindImageViewToPictureOfTheDay(pictureOfDay: PictureOfDay?) {
    pictureOfDay?.url.let { url ->
        Picasso.get().load(url).into(this)
    }
}
@BindingAdapter("accessibilityPictureOfTheDay")
fun ImageView.bindAccessibilityPictureOfTheDay(value: String?) {
    contentDescription = if (value != null) {
        context.getString(
                R.string.nasa_picture_of_day_content_description_format,
                value
        )
    } else {
        context.getString(R.string.this_is_nasa_s_picture_of_day_showing_nothing_yet)
    }
}

@BindingAdapter("astronomicalUnitText")
fun TextView.bindTextViewToAstronomicalUnit(number: Double) {
    val context = context
    text = String.format(context.getString(R.string.astronomical_unit_format), number)
}

@BindingAdapter("kmUnitText")
fun TextView.bindTextViewToKmUnit(number: Double) {
    val context = context
    text = String.format(context.getString(R.string.km_unit_format), number)
}

@BindingAdapter("velocityText")
fun TextView.bindTextViewToDisplayVelocity(number: Double) {
    val context = context
    text = String.format(context.getString(R.string.km_s_unit_format), number)
}
// Detail Fragment Binding Adapters

@BindingAdapter("asteroidStatusImage")
fun ImageView.bindDetailsStatusImage(isHazardous: Boolean) {
    if (isHazardous) {
        contentDescription = "Potentially Hazardous Asteroid"
        setImageResource(R.drawable.asteroid_hazardous)
    } else {
        contentDescription = "Safe Asteroid"
        setImageResource(R.drawable.asteroid_safe)
    }
}


@BindingAdapter("progressBarStatus")
fun ProgressBar.bindProgressBarToStatus(status: LiveData<NetworkStatus>) {

    status?.let { status ->
        when (status) {
            NetworkStatus.LOADING -> this.visibility = View.VISIBLE
            NetworkStatus.ERROR -> this.visibility = View.INVISIBLE
            NetworkStatus.DONE -> this.visibility = View.INVISIBLE
        }
    }

}