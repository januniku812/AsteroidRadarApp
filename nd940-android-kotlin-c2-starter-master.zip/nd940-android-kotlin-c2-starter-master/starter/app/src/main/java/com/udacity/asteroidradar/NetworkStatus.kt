package com.udacity.asteroidradar
// different states of retrieving our data
enum class NetworkStatus { LOADING, ERROR, DONE }